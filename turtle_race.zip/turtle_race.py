from turtle import Turtle , Screen
import random

race_active = False
scr = Screen()
scr.setup(width = 500, height = 400)
u_guess = scr.textinput(title = "Make your bet", prompt = "Which turtle will win the race? ")
colors = ['red', 'green', 'blue','crimson', 'yellow', 'orange', 'magenta']
t_pos = [-90, -60, -30, 0, 30, 60, 90]
all_turtles = []

for i in range(0, 7):
    new_turtle = Turtle(shape = "turtle")
    new_turtle.color(colors[i])
    new_turtle.penup()
    new_turtle.goto(x = -220, y = t_pos[i])
    all_turtles.append(new_turtle)

if u_guess:
    race_active = True
while race_active: #stops premature start of race
    for turtle in all_turtles:
        if turtle.xcor() > 220:
            race_active = False
            winner = turtle.pencolor()
            if winner == u_guess:
                print(f"You won! The winner is {winner} coloured turtle.")
            else:
                print(f"You lost! The winner is {winner} coloured turtle.")
        dist = random.randint(0, 10)        
        turtle.forward(dist)

scr.exitonclick()